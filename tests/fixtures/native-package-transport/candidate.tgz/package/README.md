# Gestalt

The Gestalt command manages an isolated Codex profile, agent skills, and the
Gestalt Mobile web interface. The core CLI supports native Windows x64 and
existing Linux/macOS installations. Node.js 24 or newer and an installed Codex
CLI are required for automatic Agents setup. Linux and macOS also require Bash;
Windows does not require Bash, WSL, Developer Mode, administrator access or a compiler.

Native Windows Serena, Playwright/Chrome and Mobile hosting are deferred. Core
Agents/context-mode setup remains usable without them. Other native Windows
architectures are unsupported; macOS retains its existing best-effort Unix behavior.

```sh
npm install -g @jaromil/gestalt
gestalt cli
```

When install scripts are allowed, global installation makes the command available
and automatically installs or reconciles Gestalt Agents, their context-mode runtime, and the isolated Codex
profile under `~/.codex-gestalt`. Your normal `~/.codex` profile remains separate.

npm 12 requires approval for install scripts. Allow this package's setup with:

```sh
npm install -g @jaromil/gestalt --allow-scripts=@jaromil/gestalt
```

Use the same flag for npm 12 updates unless the package is already approved in
your npm configuration. The package does not override blocked-script policies.

On Unix, `gestalt install` can also add Mobile and the optional skill collection.
On Windows it installs the available core and reports deferred components.
Retry or refresh only Agents with `gestalt agents install` or `gestalt agents update`.
Setup errors fail the npm installation and print recovery instructions.

To install only the wrapper, use `npm install -g @jaromil/gestalt --ignore-scripts`;
run `gestalt agents install` later. Local dependency installs and npx inspection
do not automatically provision a user profile.

```sh
gestalt cli
gestalt --help
```

Update the npm-installed command with:

```sh
npm install -g @jaromil/gestalt@latest
```

`gestalt update` updates the managed components and prints the npm command for
updating this package. It preserves the npm-managed executable and package metadata.
Installing a newer global npm version also reconciles Agents automatically.

When upgrading an older installation, run `gestalt update gestalt` after updating
the npm package. It retires positively identified managed Xerj MCP entries while
preserving unrelated configuration, binaries, indexes, sessions and credentials.
Remove obsolete `--xerj` options from manually maintained Mobile launch commands.
See the [migration rules](https://dyne.github.io/gestalt/start/install#retiring-older-xerj-installations).

You can also run the command without a global installation:

```sh
npx @jaromil/gestalt --help
```

[Documentation](https://dyne.github.io/gestalt/) ·
[Source and issues](https://github.com/dyne/gestalt)
